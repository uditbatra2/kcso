<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-20 15:56:05 --> Config Class Initialized
INFO - 2021-07-20 15:56:05 --> Hooks Class Initialized
DEBUG - 2021-07-20 15:56:05 --> UTF-8 Support Enabled
INFO - 2021-07-20 15:56:05 --> Utf8 Class Initialized
INFO - 2021-07-20 15:56:05 --> URI Class Initialized
INFO - 2021-07-20 15:56:05 --> Router Class Initialized
INFO - 2021-07-20 15:56:05 --> Output Class Initialized
INFO - 2021-07-20 15:56:05 --> Security Class Initialized
DEBUG - 2021-07-20 15:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-20 15:56:05 --> Input Class Initialized
INFO - 2021-07-20 15:56:05 --> Language Class Initialized
INFO - 2021-07-20 15:56:05 --> Loader Class Initialized
INFO - 2021-07-20 19:26:05 --> Helper loaded: url_helper
INFO - 2021-07-20 19:26:05 --> Helper loaded: file_helper
INFO - 2021-07-20 19:26:05 --> Helper loaded: form_helper
INFO - 2021-07-20 19:26:05 --> Helper loaded: html_helper
INFO - 2021-07-20 19:26:05 --> Helper loaded: security_helper
INFO - 2021-07-20 19:26:05 --> Helper loaded: common_helper
INFO - 2021-07-20 19:26:05 --> Database Driver Class Initialized
INFO - 2021-07-20 19:26:05 --> Email Class Initialized
DEBUG - 2021-07-20 19:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-20 19:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-20 19:26:05 --> Form Validation Class Initialized
INFO - 2021-07-20 19:26:05 --> User Agent Class Initialized
INFO - 2021-07-20 19:26:05 --> Model "Base_model" initialized
INFO - 2021-07-20 19:26:05 --> Model "Admin_model" initialized
INFO - 2021-07-20 19:26:05 --> Model "Product_model" initialized
INFO - 2021-07-20 19:26:05 --> Model "User_model" initialized
INFO - 2021-07-20 19:26:05 --> Controller Class Initialized
INFO - 2021-07-20 19:26:05 --> File loaded: C:\xampp\htdocs\ci-demo\application\views\Admin/include/header.php
INFO - 2021-07-20 19:26:05 --> File loaded: C:\xampp\htdocs\ci-demo\application\views\Admin/include/left-menu.php
INFO - 2021-07-20 19:26:05 --> File loaded: C:\xampp\htdocs\ci-demo\application\views\Admin/theme-settings.php
INFO - 2021-07-20 19:26:05 --> File loaded: C:\xampp\htdocs\ci-demo\application\views\Admin/include/footer.php
INFO - 2021-07-20 19:26:05 --> Final output sent to browser
DEBUG - 2021-07-20 19:26:05 --> Total execution time: 0.1820
INFO - 2021-07-20 15:56:16 --> Config Class Initialized
INFO - 2021-07-20 15:56:16 --> Hooks Class Initialized
DEBUG - 2021-07-20 15:56:16 --> UTF-8 Support Enabled
INFO - 2021-07-20 15:56:16 --> Utf8 Class Initialized
INFO - 2021-07-20 15:56:16 --> URI Class Initialized
INFO - 2021-07-20 15:56:16 --> Router Class Initialized
INFO - 2021-07-20 15:56:16 --> Output Class Initialized
INFO - 2021-07-20 15:56:16 --> Security Class Initialized
DEBUG - 2021-07-20 15:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-20 15:56:16 --> Input Class Initialized
INFO - 2021-07-20 15:56:16 --> Language Class Initialized
INFO - 2021-07-20 15:56:16 --> Loader Class Initialized
INFO - 2021-07-20 19:26:16 --> Helper loaded: url_helper
INFO - 2021-07-20 19:26:16 --> Helper loaded: file_helper
INFO - 2021-07-20 19:26:16 --> Helper loaded: form_helper
INFO - 2021-07-20 19:26:16 --> Helper loaded: html_helper
INFO - 2021-07-20 19:26:16 --> Helper loaded: security_helper
INFO - 2021-07-20 19:26:16 --> Helper loaded: common_helper
INFO - 2021-07-20 19:26:16 --> Database Driver Class Initialized
INFO - 2021-07-20 19:26:16 --> Email Class Initialized
DEBUG - 2021-07-20 19:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-20 19:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-20 19:26:16 --> Form Validation Class Initialized
INFO - 2021-07-20 19:26:16 --> User Agent Class Initialized
INFO - 2021-07-20 19:26:16 --> Model "Base_model" initialized
INFO - 2021-07-20 19:26:16 --> Model "Admin_model" initialized
INFO - 2021-07-20 19:26:16 --> Model "Product_model" initialized
INFO - 2021-07-20 19:26:16 --> Model "User_model" initialized
INFO - 2021-07-20 19:26:16 --> Controller Class Initialized
ERROR - 2021-07-20 16:04:07 --> 404 Page Not Found: Uploads/product_images
ERROR - 2021-07-20 16:06:41 --> 404 Page Not Found: Uploads/product_images
ERROR - 2021-07-20 16:08:06 --> 404 Page Not Found: Uploads/product_images
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1398
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1399
ERROR - 2021-07-20 19:38:17 --> Severity: Warning --> unlink(): Invalid argument C:\xampp\htdocs\ci_demo\application\controllers\Admin.php 1400
ERROR - 2021-07-20 19:38:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ci_demo\system\core\Exceptions.php:271) C:\xampp\htdocs\ci_demo\system\helpers\url_helper.php 564
